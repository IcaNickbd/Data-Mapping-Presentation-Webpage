// js/script.js
document.addEventListener('DOMContentLoaded', () => {
  const dropdowns = document.querySelectorAll('.nav-item.dropdown');
  dropdowns.forEach(item => {
    const link = item.querySelector('.nav-link');
    const menu = item.querySelector('.dropdown-menu');
    link.addEventListener('click', e => {
      e.preventDefault();
      // 切换当前下拉；关闭其他所有下拉
      document.querySelectorAll('.dropdown-menu.show')
        .forEach(m => m !== menu && m.classList.remove('show'));
      menu.classList.toggle('show');
    });
  });

  // 点击空白收起
  document.addEventListener('click', e => {
    if (!e.target.closest('.nav-item')) {
      document.querySelectorAll('.dropdown-menu.show')
        .forEach(m => m.classList.remove('show'));
    }
  });
});
//----------------------------------
// 实时时间显示模块
function updateTime() {
  const now = new Date();
  const datetimeStr = now.getFullYear() + "年" +
    String(now.getMonth() + 1).padStart(2, '0') + "月" +
    String(now.getDate()).padStart(2, '0') + "日 " +
    String(now.getHours()).padStart(2, '0') + ":" +
    String(now.getMinutes()).padStart(2, '0') + ":" +
    String(now.getSeconds()).padStart(2, '0');
  document.getElementById("datetime").innerText = datetimeStr;
}

// 每秒更新时间
setInterval(updateTime, 1000);
updateTime(); // 首次加载立即调用
